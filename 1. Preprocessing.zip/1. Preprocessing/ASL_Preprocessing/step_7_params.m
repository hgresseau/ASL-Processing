{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "18873acf-0592-44f8-ad49-b3f9774c17bd",
      "cell_type": "code",
      "source": "% Define the directory where the file will be saved\ndata_path = '/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/data/';\n\n% Define the content for the file (excluding repeats)\nparams = {\n    '--casl'\n    '--t1=1.4'\n    '--t1b=1.65'\n    '--tau=1.8'\n    '--bat=1.3'\n    '--pld=1.3'\n};\n\n% List of subjects with their corresponding repeats\nsubjects_repeats = {\n    '016', 14;\n    '017', 14;\n    '018', 14;\n    '019', 14;\n    '020', 12;\n    '021', 14;\n    '023', 14;\n    '024', 14;\n    '025', 14;\n    '026', 13;\n    '030', 14;\n    '031', 11\n};\n\n% Loop through each subject and generate the params.txt file\nfor z = 1:size(subjects_repeats, 1)\n    subj = subjects_repeats{z, 1};  % Subject ID\n    repeats = subjects_repeats{z, 2};  % Number of repeats\n\n    % Create the final params list, including the dynamic repeats value\n    params_with_repeats = [params; {['--repeats=', num2str(repeats)]}];\n\n    % Define the file path to save the params.txt\n    file_path = fullfile(data_path, ['COVIRM-', subj], 'params.txt');\n    \n    % Open the file for writing\n    fileID = fopen(file_path, 'w');\n    \n    % Write each line to the file\n    for i = 1:length(params_with_repeats)\n        fprintf(fileID, '%s\\n', params_with_repeats{i});\n    end\n    \n    % Close the file\n    fclose(fileID);\n    \n    fprintf('Params file created for subject %s: %s\\n', subj, file_path);\nend\n\ndisp('All params files created successfully!');\n\n",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}