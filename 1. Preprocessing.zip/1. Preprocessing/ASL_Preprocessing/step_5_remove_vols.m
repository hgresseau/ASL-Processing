{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "2decab7c-6d29-4feb-94a3-94ff2753a5e3",
      "cell_type": "code",
      "source": "close all;\n\n% Define paths\ndata_path = '/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/data/';\naddpath('/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/NIfTI_tools/')\n%% notes\n% subjects={'016','017','018','019','020','021','023','024','025','026','030','031'};\n% subject #020: remove volumes 1 and 13\n% subject #026: remove volume 4\n% subject #031: remove volumes 1, 2 and 3\nsubjects = {'031'}; % Add more subjects as needed\n\n\nfor z = 1:length(subjects)\n    subj = subjects{z};\n    \n    % Define file paths\n    pcasl_sub = [data_path 'COVIRM-' subj '/perf/sub-' subj '_asl_sub.nii.gz'];\n    pcasl_new = [data_path 'COVIRM-' subj '/perf/sub-' subj '_asl_sub_new.nii.gz']; % Output file after removing outliers\n\n    % Load subtracted ASL image\n    nii = load_untouch_nii(pcasl_sub);\n    sub_im = nii.img; % Extract image data\n\n    % remove vol 1, 2 and 3\n    new_img = sub_im(:,:,:, 4:end);\n\n    % remove vol 1 \n    %new_img = new_img(:,:,:, 2:end);\n\n    % Save the new perfusion-weighted image\n    nii.img = new_img;\n    nii.hdr.dime.dim(5) = size(new_img, 4); % Update header for correct volume count\n    save_untouch_nii(nii, pcasl_new);\n    \n    fprintf('Processed subject %s. Saved as %s\\n', subj, pcasl_new);\nend\n\ndisp('All selected subjects processed successfully!');\n\n\n\n\nfunction [ D_ASL_vol ] = surround_subtraction( ASL_vol )\n\n    ASL_T=ASL_vol(:,:,:,1:2:end); % TAG\n    ASL_C=ASL_vol(:,:,:,2:2:end); % Control\n    t=size(ASL_C,4);\n    vol_t(:,:,:,1)=ASL_C(:,:,:,1)-ASL_T(:,:,:,1);\n    c=2;\n    for i=1:1:t-1\n\n       vol_t(:,:,:,c)=(ASL_C(:,:,:,i)+ASL_C(:,:,:,i+1))./2-ASL_T(:,:,:,i);\n        c=c+1;\n    end\n\n    D_ASL_vol=(vol_t(:,:,:,1:end));\n\nend\n",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}