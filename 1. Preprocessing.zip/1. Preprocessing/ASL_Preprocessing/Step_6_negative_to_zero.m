{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "7a636df3-c467-4fd8-9c1e-69c5b4e620b1",
      "cell_type": "code",
      "source": "close all;\n\n% Define paths\ndata_path = '/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/data/';\naddpath('/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/NIfTI_tools/')\n\n\n% Define participants\n% subjects={'016','017','018','019','021','023','024','025','030'};\n% file name: '_asl_sub.nii.gz'\n% Different file name for participants 020, 026 and 031\n% file name: '_asl_sub_new.nii.gz'\nsubjects={'020','026','031'};\n\n% Loop through each participant\nfor z = 1:length(subjects)\n    subj = subjects{z};\n\n    % Define file paths\n    pcasl_sub = [data_path 'COVIRM-' subj '/perf/sub-' subj '_asl_sub_new.nii.gz'];\n    pcasl_zeroed = [data_path 'COVIRM-' subj '/perf/sub-' subj '_asl_sub_new.nii.gz']; % Output file\n\n    % Load ASL image\n    nii = load_untouch_nii(pcasl_sub);\n    sub_im = nii.img; % Extract image data\n    \n    % Ensure all negative voxels are set to zero\n    sub_im(sub_im < 0) = 0;\n\n    % Save the new subtracted image after processing\n    nii.img = sub_im;\n    nii.hdr.dime.dim(5) = size(sub_im, 4); % Update the header for correct volume count\n    save_untouch_nii(nii, pcasl_zeroed);\n\n    fprintf('Processed subject %s, saved as %s\\n', subj, pcasl_zeroed);\nend\n\ndisp('All subjects processed successfully!');\n\n\n\n\n\n\n\n% Surround subtraction function\nfunction [ D_ASL_vol ] = surround_subtraction( ASL_vol )\n    ASL_T = ASL_vol(:,:,:,1:2:end); % TAG\n    ASL_C = ASL_vol(:,:,:,2:2:end); % Control\n    t = size(ASL_C, 4);\n    vol_t(:,:,:,1) = ASL_C(:,:,:,1) - ASL_T(:,:,:,1);\n    c = 2;\n    for i = 1:t-1\n        vol_t(:,:,:,c) = (ASL_C(:,:,:,i) + ASL_C(:,:,:,i+1)) / 2 - ASL_T(:,:,:,i);\n        c = c + 1;\n    end\n    D_ASL_vol = vol_t(:,:,:,1:end);\nend\n",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}