{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "e0bf5b95-8d7b-4cd4-a351-f996da297fa3",
      "cell_type": "code",
      "source": "% Add necessary paths for NIfTI and SPM toolboxes\naddpath(genpath('/NAS/home/s_sanami/Documents/toolbox/NIfTI_20140122/'))\naddpath(genpath('/NAS/home/s_sanami/Documents/ASLtoobox/spm12'))\naddpath(genpath('/NAS/home/s_sanami/Documents/Scripts/CIRM'))\n% Add necessary paths for NIfTI and SPM toolboxes\naddpath(genpath('/NAS/home/s_sanami/Documents/toolbox/NIfTI_20140122/'))\naddpath(genpath('/NAS/home/s_sanami/Documents/ASLtoobox/spm12'))\naddpath(genpath('/NAS/home/s_sanami/Documents/Scripts/CIRM'))\n\n% Define paths\ndata_path = '/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/data/';\n%code_path = '/NAS/home/s_sanami/Documents/Scripts/ASLcodes';\n\n% Define subjects and rests\n% subjects={'016','017','018','019','020','021','023','024','025','026','030','031'};\nsubjects = {'016','017','018','019','020','021','023','024','025','026','030','031'}; % Add more subjects as needed\n\n% Initialize cell arrays to store results\nresults = struct();\noutlier_summary = {};  % Initialize a cell array to store subject ID and volume indices\n\n% Loop through each subject\nfor i = 1:length(subjects)\n    subject_id = subjects{i};\n    \n    % Load Rest image\n    rest_path = [data_path 'COVIRM-' subject_id '/perf/sub-' subject_id '_asl_sub.nii.gz'];\n    rest = load_untouch_nii(rest_path);    \n    rest_im = double(rest.img); % Convert to double for calculations\n    \n    % Calculate number of volumes\n    num_volumes_rest = size(rest_im, 4);\n    \n    % Calculate mean images for each image type\n    mean_rest = mean(rest_im, 4);\n    \n    % Calculate voxel-wise standard deviation images\n    sd_rest_img = std(rest_im, 0, 4);\n    \n    % Initialize arrays to store outlier percentages for each volume\n    outlier_percentage_rest = zeros(1, num_volumes_rest);\n    \n    % Store volume indices with more than 1% outliers\n    volumes_with_high_outliers = struct('rest', []);\n    \n    % Calculate outlier percentages for Rest\n    for v = 1:num_volumes_rest\n        % Calculate outliers for Rest\n        outliers_rest = abs(rest_im(:, :, :, v) - mean_rest) > 2 * sd_rest_img;\n        num_outliers_rest = sum(outliers_rest(:));\n        total_voxels_rest = numel(rest_im(:, :, :, v));\n        outlier_percentage_rest(v) = (num_outliers_rest / total_voxels_rest) * 100;\n        \n        % Check if outlier percentage is greater than 1%\n        if outlier_percentage_rest(v) > 1.5\n            volumes_with_high_outliers.rest = [volumes_with_high_outliers.rest, v];\n        end\n    end\n    \n    % Store results for the current subject\n    results(i).subject_id = subject_id;\n    results(i).num_volumes_rest = num_volumes_rest;\n    results(i).outlier_percentages_rest = outlier_percentage_rest;\n    \n    % Add to outlier summary if there are any volumes with more than 1% outliers\n    if ~isempty(volumes_with_high_outliers.rest)\n        outlier_summary = [outlier_summary; {subject_id, 'rest', volumes_with_high_outliers.rest}];\n    end\n    \n    % Print results for each subject\n    fprintf('Subject %s:\\n', subject_id);\n    fprintf('Rest Outlier Percentages: %s\\n', num2str(outlier_percentage_rest));\n    fprintf('Number of Volumes (Rest): %d, %d, %d\\n\\n', num_volumes_rest);\nend\n\n% Save the results to a .mat file\nsave('subject_outlier_analysis.mat', 'results', 'outlier_summary');\n\n% Print outlier summary\nfprintf('Outlier Summary:\\n');\nfor j = 1:size(outlier_summary, 1)\n    fprintf('Subject ID: %s, Image Type: %s, Volumes with >1%% Outliers: %s\\n', ...\n        outlier_summary{j, 1}, outlier_summary{j, 2}, num2str(outlier_summary{j, 3}));\nend\n\n",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}