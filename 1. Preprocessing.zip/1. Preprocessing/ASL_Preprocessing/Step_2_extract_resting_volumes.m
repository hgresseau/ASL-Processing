{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "4e248c49-bb39-44d7-8004-52729822c15d",
      "cell_type": "code",
      "source": "clear; clc;\n\n% Define the data path\ndata_path = '/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/data/';\n\n%% notes\n% subjects={'016','017','018','019','020','021','023','024','025','026','030','031'};\n%% patients rest\nsubjects={'016','017','018','019','020','021','023','024','025','026','030','031'};\n\n% Number of volumes to extract\nnum_volumes = 30; % First 30 volumes\n\nfor i = 1:length(subjects)\n    sub_id = subjects{i};\n    \n    % Input and output file paths ASL\n    input_file = [data_path 'COVIRM-' sub_id '/perf/sub-' sub_id '_asl_mc_bet.nii.gz'];\n    output_file = [data_path 'COVIRM-' sub_id '/perf/sub-' sub_id '_asl_mc_bet_rest.nii.gz'];\n    \n    % FSL command to extract volumes\n    cmd = sprintf('fslroi %s %s 0 %d', input_file, output_file, num_volumes);\n    \n    % Run the command\n    system(cmd);\n    \n    fprintf('Extracted resting-state volumes for subject %s\\n', sub_id);\nend\n\n%% Run this command in the Command Window\n%Step_2_extract_resting_volumes\n",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}