{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "549ba7dc-7578-40ff-88f9-7621dd12cf8a",
      "cell_type": "code",
      "source": "close all;\n\n% Define paths\ndata_path = '/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/data/';\n% addpath('/NAS/home/s_sanami/Documents/covirm_data_processing/Hendrale/NIfTI_tools/')\n%% notes\n% subjects={'016','017','018','019','020','021','023','024','025','026','030','031'};\nsubjects = {'016','017','018','019','020','021','023','024','025','026','030','031'}; % Add more subjects as needed\n\nfor z = 1:length(subjects)\n    subj = subjects{z};\n    \n    % Define file paths\n    pcasl_rest = [data_path 'COVIRM-' subj '/perf/sub-' subj '_asl_mc_bet_rest.nii.gz'];\n    pcasl_sub = [data_path 'COVIRM-' subj '/perf/sub-' subj '_asl_sub.nii.gz']; % Output file\n    \n    % Load ASL image\n    nii = load_untouch_nii(pcasl_rest);\n    ASL_vol = nii.img; % Extract image data\n    \n    % Load data and remove the first time point\n    ASL_vol = ASL_vol(:,:,:,3:end);\n    \n    \n    % Apply surround subtraction\n    D_ASL_vol = surround_subtraction(ASL_vol);\n    \n    % Save the new perfusion-weighted image\n    nii.img = D_ASL_vol;\n    nii.hdr.dime.dim(5) = size(D_ASL_vol, 4); % Update the header for correct volume count\n    save_untouch_nii(nii, pcasl_sub);\n    \n    fprintf('Surround subtraction complete for subject %s. Saved as %s\\n', subj, pcasl_sub);\n    \n    \nend\n\ndisp('All subjects processed successfully!');\n\n\n\n\n\n\nfunction [ D_ASL_vol ] = surround_subtraction( ASL_vol )\n\n    ASL_T=ASL_vol(:,:,:,1:2:end); % TAG\n    ASL_C=ASL_vol(:,:,:,2:2:end); % Control\n    t=size(ASL_C,4);\n    vol_t(:,:,:,1)=ASL_C(:,:,:,1)-ASL_T(:,:,:,1);\n    c=2;\n    for i=1:1:t-1\n\n       vol_t(:,:,:,c)=(ASL_C(:,:,:,i)+ASL_C(:,:,:,i+1))./2-ASL_T(:,:,:,i);\n        c=c+1;\n    end\n\n    D_ASL_vol=(vol_t(:,:,:,1:end));\n\nend\n",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}