{
  "metadata": {
    "kernelspec": {
      "name": "python",
      "display_name": "Python (Pyodide)",
      "language": "python"
    },
    "language_info": {
      "name": ""
    }
  },
  "nbformat_minor": 5,
  "nbformat": 4,
  "cells": [
    {
      "id": "6619dd10-298e-4522-bdd9-6eea20f3b0bc",
      "cell_type": "code",
      "source": "%Fatemeh Razavipour, July 2019\n\nfunction [ D_ASL_vol ] = surround_subtraction( ASL_vol )\n\n    ASL_T=ASL_vol(:,:,:,1:2:end); % TAG\n    ASL_C=ASL_vol(:,:,:,2:2:end); % Control\n    t=size(ASL_C,4);\n    vol_t(:,:,:,1)=ASL_C(:,:,:,1)-ASL_T(:,:,:,1);\n    c=2;\n    for i=1:1:t-1\n\n       vol_t(:,:,:,c)=(ASL_C(:,:,:,i)+ASL_C(:,:,:,i+1))./2-ASL_T(:,:,:,i);\n        c=c+1;\n    end\n\n    D_ASL_vol=(vol_t(:,:,:,1:end));\n\nend",
      "metadata": {
        "trusted": true
      },
      "outputs": [],
      "execution_count": null
    }
  ]
}